const devURL = "http://localhost:3003";
const serverURL  = 'https://king-drag.herokuapp.com';

export const ServerURL = serverURL;
