
import BaseDTO from './BaseDTO';

class GroupsDTO extends BaseDTO {
    constructor() {
        super();
    }
    
}

export default new GroupsDTO();